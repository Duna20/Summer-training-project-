
exports.homepage = async(req,res)=>{
    
    res.render('index');


}





exports.explpreCollection = async(req,res)=>{
    
    res.render('Collection');


}





exports.JContact2 = async(req,res)=>{
    
    res.render('Contact2');


}
exports.Jaboutus = async(req,res)=>{
    
    res.render('aboutus');


}


exports.Jsearch = async(req, res) => {

    res.render('search');
  
}

exports.Jcol1 = async(req,res)=>{
    
    res.render('col1');


}

exports.Jcol2 = async(req,res)=>{
    
    res.render('col2');


}

exports.Jcol3 = async(req,res)=>{
    
    res.render('col3');


}